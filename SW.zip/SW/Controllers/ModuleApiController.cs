﻿using SW.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SW.Controllers
{
    public class ModuleApiController : BaseApiController
    {
        public void GetModuleByIndex()
        {
            // 查询 Module 根据权限 如果存在Html删除 否则 生成后返回List 
            
        }
      
    }
}
